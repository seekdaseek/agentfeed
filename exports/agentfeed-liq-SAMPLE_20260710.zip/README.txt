AGENTFEED Liquidation Dataset — build 20260710
=============================================
Multi-exchange crypto perpetual liquidation ticks.

COVERAGE
- Symbols: SOLUSDT, BTCUSDT (from 2026-07-08); ETHUSDT, XRPUSDT, DOGEUSDT (from 2026-07-10)
- Exchanges: Bybit (complete allLiquidation feed), OKX (sampled by exchange, max ~1 print/sec/contract)
- Rows: 1484 | Range (UTC): 2026-07-08 16:42:32 -> 2026-07-09 23:35:19

SCHEMA (CSV)
ts_ms       epoch milliseconds of liquidation
utc_time    human-readable UTC
symbol      e.g. SOLUSDT
exchange    bybit | okx
event       long_liquidated | short_liquidated
size        position size in coins (OKX converted via contract value)
price       bankruptcy/execution price
usd         size * price, rounded 2dp

HONEST CAVEATS
- OKX feed is sampled BY THE EXCHANGE; treat OKX rows as representative, not exhaustive.
- Bybit rows are the complete public liquidation stream.
- Collector downtime gaps possible; cross-check row continuity for your window.

LICENSE: single-seat, personal or internal commercial use. No redistribution or resale.
Real-time access for AI agents: https://x402.ochinimus.app
